fx_version 'cerulean'
game 'gta5'

client_script {
'gz.lua',
}

client_scripts {
	"main.lua"
}